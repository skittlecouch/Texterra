//screen for battling monsters, takes in monster object in constructor
//TODO: player status effects in update labels method
//TODO: maybe add mob loot tables inside battle screen as unlockable thingy
//TODO: add item durability stat tracker for battle
//TODO: Handle player victory (gain XP, items, etc.) [in AttackButtonListener class] 
//TODO: Handle player defeat [in AttackButtonListener]
//TODO: Flee button returns to area screen depending on what area you came in from
//TODO: Defense calculations


package screens.ui;

import game.BaseScreenPanel;
import game.Texterra;
import entities.Monster; // Import Monster
import entities.Player;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class BattleScreenPanel extends BaseScreenPanel {

	//VARIABLES
//Entities
    private Player player;
    private Monster monster; // Store the Monster object directly
    
//Player stats (Instantiated here and not in the constructor because of scope for some of them, update stats methods will need to update these labels especially when potions are added
    private JLabel playerLevelLabel; //includes xp count
    private JLabel playerHealthLabel;
    private JLabel playerAttackLabel;
    private JLabel playerDefenseLabel;
    private JLabel playerSpeedLabel;
    private JLabel playerCritStatsLabel;
    private JLabel playerEquipmentLabel; //Weapon and Armor
    private JLabel playerStatusEffectsLabel; //For food, potions, and status effects

    
//Monster stats
    private JLabel monsterLevelLabel;
    private JLabel monsterHealthLabel;
    private JLabel monsterAttackLabel;
    private JLabel monsterDefenseLabel;
    private JLabel monsterSpeedLabel;
    private JLabel monsterCritStatsLabel;
    
    //maybe adding a way to see mob loot table in battle, unlockable later in game?? if you do add it here
    
    
    private JTextArea consoleTextArea;

    
    
    //METHODS
    private void updateLabels() {
    	
    	//Player stats
        playerLevelLabel.setText("Player Level: " + player.getLevel() + " / " + player.getXpRequirement()); //includes xp count
        playerHealthLabel.setText("Health: " + player.getHealth() + " / " + player.getMaxHealth());
        playerAttackLabel.setText("Attack Damage: " + player.getEquippedWeapon().getDamage());
        playerDefenseLabel.setText("Defense: " + player.getEquippedArmor().getArmorItem().getDefense());
        playerSpeedLabel.setText("Speed: " + player.getSpeed());
        playerCritStatsLabel.setText("Crit Chance: " + player.getCritChance() + ", Crit Damage: " + player.getCritDamage());
        playerEquipmentLabel.setText("Weapon: " + player.getEquippedWeapon().getName() + ", Armor: " + player.getEquippedArmor().getName()); //Weapon and Armor
        playerStatusEffectsLabel.setText("Effects: N/A"); //For food, potions, and status effects (not implemented yet)
        
        //Monster stats
        monsterLevelLabel.setText(monster.getMonsterEntity().getName() + ", Level: " + monster.getMonsterEntity().getLevel());
        monsterHealthLabel.setText("Health: " + monster.getCurrentHealth() + " / " + monster.getMonsterEntity().getMaxHealth());
        monsterAttackLabel.setText("Attack Damage: " + monster.getMonsterEntity().getAttack());
        monsterDefenseLabel.setText("Defense: " + monster.getMonsterEntity().getDefense());
        monsterSpeedLabel.setText("Speed: " + monster.getMonsterEntity().getSpeed());
        monsterCritStatsLabel.setText("Crit Chance: " + monster.getMonsterEntity().getCritChance() + ", Crit Damage: " + monster.getMonsterEntity().getCritDamage());
        
    }
    
    private void appendToConsole(String text) {
    	
        consoleTextArea.append(text + "\n");
        consoleTextArea.setCaretPosition(consoleTextArea.getDocument().getLength()); // Scroll to bottom
        
    }
    
    
    
    //HELPER METHODS
    
    //CONSTRUCTORS
    public BattleScreenPanel(Texterra mainFrame, Monster monster) { // Change the constructor
    	
        super(mainFrame);
        this.player = mainFrame.getMainScreenPanel().getPlayer(); //loads player
        
        
        //null case!!
        if (monster == null) {
        	
        	monster = new Monster();
        	
        } else {
        
        	this.monster = monster; // Store the Monster object
        
        }
        
        
        setLayout(new BorderLayout());

        
        
        // --- Top Panel (Monster Name) ---
        JPanel topPanel = new JPanel();
        
        JLabel titleLabel = new JLabel("Battle with " + monster.getMonsterEntity().getName() + "!");
        
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        topPanel.add(titleLabel);
        
        add(topPanel, BorderLayout.NORTH);

        
        
        // --- Center Panel (Stats and Console) ---
        JPanel centerPanel = new JPanel();
        JPanel battlePanel = new JPanel();
        JPanel playerPanel = new JPanel();
        JPanel monsterPanel = new JPanel();
        
        
        centerPanel.setLayout(new GridLayout(2,1)); // 2 rows, 1 column
        
        battlePanel.setLayout(new BorderLayout());
        battlePanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 100, 10));
        
        playerPanel.setLayout(new BoxLayout(playerPanel, BoxLayout.Y_AXIS));
        monsterPanel.setLayout(new BoxLayout(monsterPanel, BoxLayout.Y_AXIS));
        
        
        //Player stats
        playerLevelLabel = new JLabel(); //includes xp count
        playerHealthLabel = new JLabel();
        playerAttackLabel = new JLabel();
        playerDefenseLabel = new JLabel();
        playerSpeedLabel = new JLabel();
        playerCritStatsLabel = new JLabel();
        playerEquipmentLabel = new JLabel(); //Weapon and Armor
        playerStatusEffectsLabel = new JLabel(); //For food, potions, and status effects

        
        //Monster stats
        monsterLevelLabel = new JLabel();
        monsterHealthLabel = new JLabel();
        monsterAttackLabel = new JLabel();
        monsterDefenseLabel = new JLabel();
        monsterSpeedLabel = new JLabel();
        monsterCritStatsLabel = new JLabel();
        
        
        updateLabels(); // Update labels

        
        consoleTextArea = new JTextArea(10, 40);
        consoleTextArea.setEditable(false);
        consoleTextArea.setLineWrap(true);
        consoleTextArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(consoleTextArea);
        
        
        
        //Player labels
        playerPanel.add(playerLevelLabel);
        playerPanel.add(playerHealthLabel);
        playerPanel.add(playerAttackLabel);
        playerPanel.add(playerDefenseLabel);
        playerPanel.add(playerSpeedLabel);
        playerPanel.add(playerCritStatsLabel);
        playerPanel.add(playerEquipmentLabel);
        playerPanel.add(playerStatusEffectsLabel);
        
        
        
        //Monster labels
        monsterPanel.add(monsterLevelLabel);
        monsterPanel.add(monsterHealthLabel);
        monsterPanel.add(monsterAttackLabel);
        monsterPanel.add(monsterDefenseLabel);
        monsterPanel.add(monsterSpeedLabel);
        monsterPanel.add(monsterCritStatsLabel);
        
        

        battlePanel.add(playerPanel, BorderLayout.WEST);
        battlePanel.add(monsterPanel, BorderLayout.EAST);
        
        
        
        centerPanel.add(battlePanel);
        centerPanel.add(scrollPane);

        add(centerPanel, BorderLayout.CENTER);

        
        
        // --- Bottom Panel (Buttons) ---
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new GridLayout(1,3));
        
        JButton attackButton = new JButton("Attack");
        JButton potionButton = new JButton("Use Equipped Potion");
        JButton fleeButton = new JButton("Flee");

        attackButton.addActionListener(new AttackButtonListener(attackButton)); // Use inner class
        //potionButton.addActionListener(); //use potion
        fleeButton.addActionListener(e -> getMainFrame().showScreen(Texterra.MAIN_SCREEN));

        bottomPanel.add(potionButton);
        bottomPanel.add(attackButton);
        bottomPanel.add(fleeButton);
        
        add(bottomPanel, BorderLayout.SOUTH);
                
    } //end constructor



    
    
    // Inner class for handling attack button clicks
    private class AttackButtonListener implements ActionListener {
    	
    	private JButton button;
    	
    	public AttackButtonListener(JButton button) {
    		this.button = button;
    	}
    	
        @Override
        public void actionPerformed(ActionEvent e) {
        	
            // Player's turn
            int playerDamage = player.attack(monster);

            //Apply damage to the monster
            appendToConsole("Player attacks " + monster.getMonsterEntity().getName() + " for " + playerDamage + " damage.");
            updateLabels();

            // Check if monster is defeated
            if (monster.getCurrentHealth() <= 0) {
            	monster.setCurrentHealth(0);
            	button.setEnabled(false);
                appendToConsole(monster.getMonsterEntity().getName() + " defeated!");
                // TODO: Handle victory (gain XP, items, etc.)
                
                
                
                
                
                
                

                return; // Exit the method - VERY IMPORTANT (cuz if monster dies it doesnt attack the player) [BUT WHAT ABOUT SPEED STAT THO]
            }

            // Monster's turn (if not defeated)
            int monsterDamage = monster.attack();

            //Add armor defense if armor equipped
            if(player.getEquippedArmor() != null) {
                monsterDamage -= player.getEquippedArmor().getArmorItem().getDefense(); //---------------------------------------------------------------------------------------DEFENSE CALCULATION
            }

            //Ensure monster never deals negative damage
            if(monsterDamage < 0) {
                monsterDamage = 0;
            }

            //Apply damage to player
            player.setHealth(player.getHealth() - monsterDamage);
            appendToConsole(monster.getMonsterEntity().getName() + " attacks Player for " + monsterDamage + " damage." + "\n");
            updateLabels();

            // Check if player is defeated
            if (player.getHealth() <= 0) {
                appendToConsole("Player defeated!");
             // TODO: Handle defeat
                
                
                getMainFrame().getMainScreenPanel().refreshStats();
                getMainFrame().showScreen(Texterra.MAIN_SCREEN);
            }
            
        } //end constructor
        
    } //end inner class
    
} //end BattleScreenPanel class