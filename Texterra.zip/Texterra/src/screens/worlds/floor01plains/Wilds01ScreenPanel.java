//WILDS SCREEN, SELECT YOUR AREA! SHOULD DEPEND ON CURRENTFLOOR
//BRUH YOU DONT NEED 10 WILDS SCREEN CLASSES FOR EVERY FLOOR FFS
//TODO: add other floors to the wildsCardPanel thingy instead of the 10 different classes bs
//TODO: Fix every reference to Wilds01 bs
//TODO: player.health > 0 check preventing access to wilds



//imports
package screens.worlds.floor01plains;

import game.BaseScreenPanel;
import game.Texterra;
import game.WorldName;

//utilities
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class Wilds01ScreenPanel extends BaseScreenPanel {

	//VARIABLES
    private CardLayout wildsCardLayout;
    private JPanel wildsCardPanel;
    private PlainsPanel plainsPanel; // Add a reference

    
    
    // IMPORTANT: Method to show a specific world (by its ID) <----------------------------------------------------THIS (we dont need wilds01 02 03 ........)
    public void showWorld(WorldName theWorld) {
        wildsCardLayout.show(wildsCardPanel, theWorld.getId());
    }
    
    
    //CONSTRUCTORS (MAYBE ADD CURRENT FLOOR INTO CONSTRUCTOR DUMMY)
    public Wilds01ScreenPanel(Texterra mainFrame) {
    	
        super(mainFrame);
        setLayout(new BorderLayout());
        setBorder(mainFrame.getMainBorder());

        
        // --- Top Panel (Title) ---
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("Wilds");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(titleLabel);
        add(topPanel, BorderLayout.NORTH);

        
        // --- Center Panel (CardLayout for different worlds) ---
        wildsCardLayout = new CardLayout();
        wildsCardPanel = new JPanel(wildsCardLayout);

        plainsPanel = new PlainsPanel(mainFrame); // Create the Plains panel
        wildsCardPanel.add(plainsPanel, "[01]Plains"); // Add it with its world ID.  Keep this ID!
        // Add other world panels here as you create them

        add(wildsCardPanel, BorderLayout.CENTER);


        // --- Bottom Panel (Back Button) ---
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> mainFrame.showScreen(Texterra.MAIN_SCREEN));
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);
        
    }
    
} //end Wilds01ScreenPanel class