//Plains floor panel, contains various areas and dungeons to be explored in the wilds menu
//TODO: player.health > 0 check preventing access to wilds (maybe in wildsScreenPanel)
//TODO: add floor warmth, default maybe 100? or 0, and negatives idk
//TODO: add warmth functionality


//imports
package screens.worlds.floor01plains;

import game.BaseScreenPanel;
import game.Texterra;
import screens.worlds.floor01plains.areas.FieldsAreaScreenPanel;
import screens.ui.MainScreenPanel;
import entities.Player;


//utilities
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class PlainsPanel extends BaseScreenPanel {

	//VARIABLES
    private CardLayout areaCardLayout; // CardLayout for areas
    private JPanel areaCardPanel;      // Panel to hold area cards
    private FieldsAreaScreenPanel fieldsAreaPanel; // Instance of the new panel

 //area buttons
    private JLabel areasLabel;
    private JButton fieldsButton;
    private JButton riverButton;
    private JButton beachButton;
    private JButton hillsButton;
    private JButton forestButton;
    private JLabel dungeonsLabel;
    private JButton plantDungeonButton;
    private JButton dungeonTowerButton;
    
//area level limits
    private final int fieldsLevel = 0;  // Use final for constants
    private final int riverLevel = 5;
    private final int beachLevel = 10;
    private final int hillsLevel = 15;
    private final int forestLevel = 20;
    private final int plantDungeonLevel = 10;
    private final int dungeonTowerLevel = 20;
    
    private Player player;
    private int playerLevel;
    
    
    //METHODS
    private void showAreaNotImplemented() {
        // Use getMainFrame() for consistency
        JOptionPane.showMessageDialog(getMainFrame(), "Area not implemented yet.", "Not Implemented", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void updateAreaAccess() {
    	
    	playerLevel = getMainFrame().getMainScreenPanel().getLevel();
    	
    	fieldsButton.setEnabled(playerLevel >= fieldsLevel);
        riverButton.setEnabled(playerLevel >= riverLevel);
        beachButton.setEnabled(playerLevel >= beachLevel);
        hillsButton.setEnabled(playerLevel >= hillsLevel);
        forestButton.setEnabled(playerLevel >= forestLevel);
        plantDungeonButton.setEnabled(playerLevel >= plantDungeonLevel);
        dungeonTowerButton.setEnabled(playerLevel >= dungeonTowerLevel);
    	
    }
    
    //HELPER METHODS
    
    //CONSTRUCTORS
    public PlainsPanel(Texterra mainFrame) {
    	
    	super(mainFrame);
        setLayout(new BorderLayout()); // Use BorderLayout for overall structure
        setBorder(mainFrame.getMainBorder());
        this.player = mainFrame.getMainScreenPanel().getPlayer();

        
        // --- Top Panel (Title - Optional) ---
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("[01] Plains"); // Example title
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        topPanel.add(titleLabel);
        add(topPanel, BorderLayout.NORTH);

//TODO: check thisVVVV
        // --- Center Panel (CardLayout for Areas) ---
        areaCardLayout = new CardLayout();
        areaCardPanel = new JPanel(areaCardLayout);

        // Create instances of your area panels
        fieldsAreaPanel = new FieldsAreaScreenPanel(mainFrame);

        
        // --- Bottom Panel (Area Selection Buttons - Moved here) ---
        JPanel leftPanel = new JPanel();
        JPanel rightPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        
        // Area Buttons
        areasLabel = new JLabel("AREAS:");
        fieldsButton = new JButton("Fields (Lvl 0)");
        riverButton = new JButton("River (Lvl 5)");
        beachButton = new JButton("Beach (Lvl 10)");
        hillsButton = new JButton("Hills (Lvl 15)");
        forestButton = new JButton("Forest (Lvl 20)");
        
        dungeonsLabel = new JLabel("DUNGEONS:");
        plantDungeonButton = new JButton("Plant Dungeon (Lvl 10)");
        dungeonTowerButton = new JButton("Dungeon Tower (Lvl 20)");

        updateAreaAccess();
        
        // Add ActionListeners to switch areas (using the CardLayout)
        fieldsButton.addActionListener(e -> mainFrame.showScreen(Texterra.FIELDS_AREA_SCREEN)); 
        riverButton.addActionListener(e -> mainFrame.showScreen(Texterra.RIVER_AREA_SCREEN));
        beachButton.addActionListener(e -> mainFrame.showScreen(Texterra.BEACH_AREA_SCREEN));
        hillsButton.addActionListener(e -> mainFrame.showScreen(Texterra.HILLS_AREA_SCREEN));
        forestButton.addActionListener(e -> mainFrame.showScreen(Texterra.FOREST_AREA_SCREEN));
        plantDungeonButton.addActionListener(e -> showAreaNotImplemented());
        dungeonTowerButton.addActionListener(e -> showAreaNotImplemented());


        //ADD BUTTONS/LABELS TO PANEL
        leftPanel.add(areasLabel);
        leftPanel.add(fieldsButton);
        leftPanel.add(riverButton);
        leftPanel.add(beachButton);
        leftPanel.add(hillsButton);
        leftPanel.add(forestButton);
        
        rightPanel.add(dungeonsLabel);
        rightPanel.add(plantDungeonButton);
        rightPanel.add(dungeonTowerButton);

        add(leftPanel, BorderLayout.WEST); // Add the left panel
        add(rightPanel, BorderLayout.EAST); // Add the right panel
        
        
        
        
        
    } //end constructor
    
} //end PlainsPanel class