//Fields area, home to boars slimes and snakes



//imports
package screens.worlds.floor01plains.areas;

import game.BaseScreenPanel;
import game.Texterra;
import items.Item;
import items.Ore;
import screens.worlds.floor01plains.PlainsPanel;
import entities.Monster;
import entities.Monster.MonsterEntity;
import screens.ui.BattleScreenPanel;



//utilities
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.ArrayList;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class FieldsAreaScreenPanel extends BaseScreenPanel {
	
	//METHODS
    private void createAndShowBattleScreen(Monster battleMonster) { //SHOWS NEW BATTLESCREEN WITH GIVEN MONSTER
    	
        BattleScreenPanel battleScreen = new BattleScreenPanel(getMainFrame(), battleMonster); // Pass MONSTER
        getMainFrame().getCardPanel().add(battleScreen, Texterra.BATTLE_SCREEN); // Use constant
        getMainFrame().showScreen(Texterra.BATTLE_SCREEN);
        
    }
	
    
    
	//HELPER METHODS
	
//CONSTRUCTORS
    public FieldsAreaScreenPanel(Texterra mainFrame) {
    	
        super(mainFrame);
        setLayout(new BorderLayout()); // Example: 3 columns for monsters
        setBorder(mainFrame.getMainBorder());

        
        JPanel battlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
              
        JButton boarButton = new JButton("Fight Boars");
        JButton slimeButton = new JButton("Fight Slimes");
        JButton snakeButton = new JButton("Fight Snakes");


        boarButton.addActionListener(e -> createAndShowBattleScreen( new Monster(MonsterEntity.BOAR) )); //boar
        slimeButton.addActionListener(e -> createAndShowBattleScreen( new Monster(MonsterEntity.SLIME) )); //slime
        snakeButton.addActionListener(e -> createAndShowBattleScreen( new Monster(MonsterEntity.SNAKE) )); //snake

        
        battlePanel.add(boarButton);
        battlePanel.add(slimeButton);
        battlePanel.add(snakeButton);
        
        add(battlePanel, BorderLayout.CENTER);
        
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> mainFrame.showScreen(Texterra.WILDS01_SCREEN));
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);
        
        
    } //end constructor

} //end FieldsAreaScreenPanel class