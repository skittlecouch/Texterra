package screens.worlds.floor02snow;

public class SnowPanel {

}
