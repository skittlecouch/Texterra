package screens.worlds.floor07jungle;

public class JunglePanel {

}
