package screens.worlds.floor03desert;

public class DesertPanel {

}
