package screens.worlds.floor09archapelago;

public class ArchipelagoPanel {

}
