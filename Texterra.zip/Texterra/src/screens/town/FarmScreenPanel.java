//Farming screen, on floors with towns, allows player to use seeds to grow plants which can be used for cooking
//time based background feature
//TODO: general functionality
//TODO: requires house to be purchased to grow your own seeds, comes with set number of plots that take time to grow and require being watered 2x
//TODO: time functionality
//TODO: alerts on the main screen
//TODO: items grown take seeds from inventory and place resulting foods back in the inventory when claimed
//TODO: quality of grown foods depends on skill required of seeds and current farming skill
//TODO: purchasable auto watering system
//TODO: purchasable auto reseeding system and output storage system with autoclaim for completed foods



//imports
package screens.town;

import game.BaseScreenPanel;
import game.Texterra;



//utilities
import javax.swing.JButton;
import javax.swing.JLabel;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class FarmScreenPanel extends BaseScreenPanel {
	
	//CONSTRUCTORS
    public FarmScreenPanel(Texterra mainFrame) {
    	
        super(mainFrame);
        setBorder(mainFrame.getMainBorder());
        JLabel farmLabel = new JLabel("Farm Screen");
        JButton backButton = new JButton("Back");
		
        add(farmLabel);
        add(backButton);
		
        backButton.addActionListener(e -> mainFrame.showScreen(Texterra.TOWN_SCREEN)); // Go back to main screen
        
    }
    
} //end FarmScreenPanel class