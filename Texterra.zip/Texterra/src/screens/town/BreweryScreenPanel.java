//Brewing screen, on floors with towns, allows player to use materials from their inventory to brew potions
//TODO: general functionality
//TODO: takes various item ingredients as input
//TODO: acidity system
//TODO: time based functionality / background
//TODO: crafting recipes list with somewhat of a theme for each potion type
//TODO: quality of potions based on percentage out of 100, approaching 100%
//TODO: alternate potiion types, and multi potions at the highest quality
//TODO: potions are short duration or instant use items, lasting for the duration of the battle only



//imports
package screens.town;

import game.BaseScreenPanel;
import game.Texterra;



//utilities
import javax.swing.JButton;
import javax.swing.JLabel;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class BreweryScreenPanel extends BaseScreenPanel {
	
	//CONSTRUCTORS
    public BreweryScreenPanel(Texterra mainFrame) {
    	
        super(mainFrame);
        setBorder(mainFrame.getMainBorder());
        JLabel breweryLabel = new JLabel("Brewery Screen");
        JButton backButton = new JButton("Back");
		
        add(breweryLabel);
        add(backButton);
		
        backButton.addActionListener(e -> mainFrame.showScreen(Texterra.TOWN_SCREEN)); // Go back to main screen
        
    }
    
} //end BreweryScreenPanel class