//Player class, stores player stats
//TODO: maybe setLevel() function should also be responsible for xp requirement and xp??? maybe even strength and speed too?
//TODO: on that note maybe setWeapon() and setArmor() should also change defense and speed, maybe add a damage stat tracker too. Update stat refreshers in mainscreen and devwindow
//TODO: balance xp requirement growth rate
//TODO: Monster defeat / victory


//imports
package entities;

import items.Item;
import items.Weapon;
import items.Armor;
import game.WorldName;



//utilities
import java.util.ArrayList;
import java.util.List;
import java.util.Random;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class Player {

	//VARIABLES
    private String name;
    private int level;
    private int health;
    private int maxHealth;
    private int xp;
    private int xpRequirement;
    private int rhin;
    
    private int strength; //Base strength
    private int defense; //Base defense
    private int speed;    //Base Speed
    private double critChance;
    private double critDamage;
    
    private int cookingSkill;
    private int blacksmithingSkill;
    private int brewingSkill;
    private int farmingSkill;
    
    private WorldName currentWorld; //Store the current world ID, WHAT WORLD THE PLAYER IS CURRENTLY ON! NOT PROGRESSION STUFF
    private WorldName unlockedWorld; //Store the world ID of the highest world the player can access
    
    private Weapon equippedWeapon; //The currently equipped weapon
    private Armor equippedArmor; //The currently equipped armor
    
    private List<Item> inventory;
    private static final Random random = new Random();

    
    
    //METHODS
    
    public void updateStatsOnLevel(int newLevel) {//--------------------------------------------------------------------STAT GROWTH FORMULAS ON LEVEL UP
    	xpRequirement = newLevel * 100;
    	strength = 10 + (newLevel - 1);
    	maxHealth = 100 + ( (newLevel - 1) * 10);
    	health = maxHealth;
    }
    
    public void levelUp() { //handles multiple level ups with one call based on player.xp
    	
    	while (xp >= xpRequirement) { //xp requirement grows in this loop indefinitely until it surpasses xp
    		
    	level++;
    	xp -= xpRequirement;
    	xp = Math.max(0, xp); //prevents negative, shouldnt ever happen tho
    	updateStatsOnLevel(level);
    	
    	}
    	
    }
    
    //damages theMonster, also as a bonus returns the amount of damage applied to theMonster
    public int attack(Monster theMonster) {

    	int attack = ( strength + equippedWeapon.getDamage() );
    	
    	double theCritChance = this.critChance;
        double theCritDamage = this.critDamage;

        // Critical hit calculation
        if (random.nextDouble() <  theCritChance) {
            attack = (int) (attack * theCritDamage);
            System.out.println("Critical Hit! (player)"); // For console output
        }
        
        if (attack < 0) {
            attack = 0; // Ensure positive damage
        }
    	
        theMonster.setCurrentHealth( theMonster.getCurrentHealth() - attack );
        
        if (theMonster.getCurrentHealth() <= 0) {
        	//TODO: Monster defeat / Player victory
        	
        	theMonster.setCurrentHealth(0);
        	List<Item> monsterDrops = theMonster.calculateDrops();
        	addItemToInventory(monsterDrops);
        	System.out.println(monsterDrops);
        	
        }
        
        return attack;
        
    }
    
//Equip and unequip methods
    public void setEquippedWeapon(Weapon weapon) {
        this.equippedWeapon = weapon;
    }

    public void unequipWeapon() {
        this.equippedWeapon = null;
    }
	
	public void setEquippedArmor(Armor armor) {
		this.equippedArmor = armor;
	}
	
	public void unequipArmor() {
		this.equippedArmor = null;
	}

//Inventory management
	public void addItemToInventory(Item item) {
	    inventory.add(item);
	}
	
	public void addItemToInventory(List<Item> items) {
	    inventory.addAll(items);
	}

    public void removeItemFromInventory(Item item) {
        inventory.remove(item);
    }
    
    
    
    //HELPER METHODS
    
    //CONSTRUCTORS
    public Player(String name) {
    	
        this.name = name;
        this.level = 1; //Starting level
        this.health = 100; //Starting health
        this.maxHealth = 100; //Starting max health
        this.xp = 0; //Starting XP
        this.xpRequirement = 100; //XP needed for level 2
        this.rhin = 100; //Starting Rhin
        
        this.strength = 10; //Base strength
        this.defense = 0; //Base defense
        this.speed = 100; //Base speed (decreases as you equip gear)
        this.critChance = 0.05; //Base crit chance (5%)
        this.critDamage = 1.25; //Base crit damage multiplier (125%)
        
        this.cookingSkill = 0;
        this.blacksmithingSkill = 0;
        this.brewingSkill = 0;
        this.farmingSkill = 0;
        
        this.currentWorld = WorldName.PLAINS; //Start in [01]Plains
        this.unlockedWorld = WorldName.PLAINS; //start with only [01]Plains unlocked
        
        this.equippedWeapon = new Weapon(); //No weapon equipped initially
        this.equippedArmor = new Armor(); //No armor equipped initially
        
        this.inventory = new ArrayList<>();
        
    }
    
    
    
    //GETTERS
	public int getLevel() {
		return level;
	}

	public String getName() {
		return name;
	}

	public int getHealth() {
		return health;
	}

	public int getMaxHealth() {
		return maxHealth;
	}

	public int getXP() {
		return xp;
	}

    public int getXpRequirement() {
        return xpRequirement;
    }

	public int getRhin() {
		return rhin;
	}

	public int getStrength() {
        return strength;
    }
	
    public int getDefense() {
        return defense;
    }
    
    public int getSpeed() {
        return speed;
    }
    
    public double getCritChance() {
        return critChance;
    }
    
    public double getCritDamage() {
        return critDamage;
    }
    
	public int getCookingSkill() {
		return cookingSkill;
	}
	
	public int getBlacksmithingSkill() {
		return blacksmithingSkill;
	}
	
	public int getBrewingSkill() {
		return brewingSkill;
	}
	
	public int getFarmingSkill() {
		return farmingSkill;
	}
	
    public WorldName getCurrentWorld() {
        return currentWorld;
    }
    
    public WorldName getUnlockedWorld() {
        return unlockedWorld;
    }

    public Weapon getEquippedWeapon() {
        return equippedWeapon;
    }
    
	public Armor getEquippedArmor() {
		return equippedArmor;
	}

    public List<Item> getInventory() {
        return inventory;
    }

    
    
    //SETTERS
    public void setHealth(int health) {
        this.health = Math.max(0, Math.min(health, maxHealth));  // Keep within 0-maxHealth
    }

     public void setMaxHealth(int maxHealth) {
        this.maxHealth = Math.max(0, maxHealth); // Ensure maxHealth is not negative
        this.health = Math.min(this.health, this.maxHealth); // Ensure health doesn't exceed new max
    }

    public void setXP(int xp) {
        this.xp = Math.max(0, xp); // Prevent negative XP
    }

    public void setXpRequirement(int xpNeeded) {
        xpRequirement = xpNeeded;
    }

    public void setRhin(int rhin) {
        this.rhin = Math.max(0, rhin); // Prevent negative Rhin
    }

    public void setCookingSkill(int cookingSkill) {
        this.cookingSkill = Math.max(0, cookingSkill); // Prevent negative skill
    }
    
    public void setBlacksmithingSkill(int blacksmithingSkill) {
        this.blacksmithingSkill = Math.max(0, blacksmithingSkill); // Prevent negative skill
    }
    
    public void setBrewingSkill(int brewingSkill) {
        this.brewingSkill = Math.max(0, brewingSkill); // Prevent negative skill
    } 
    
    public void setFarmingSkill(int farmingSkill) {
        this.farmingSkill = Math.max(0, farmingSkill); // Prevent negative skill
    }

    public void setLevel(int level){
        this.level = level;
    }
    
    public void setStrength(int strength){
        this.strength = strength;
    }
    
    public void setDefense(int defense){
        this.defense = defense;
    }
    
    public void setSpeed(int speed){
        this.speed = speed;
    }
    
    public void setCurrentWorld(WorldName theWorld) {
        this.currentWorld = theWorld;
    }
    
    public void setUnlockedWorld(WorldName theWorld) {
        this.unlockedWorld = theWorld;
    }
    
} //end Player class