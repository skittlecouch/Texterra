//METHODS: int attack(int playerDefense), List<Item> calculateDrops()
//TODO: make enum for Monster containing all monsters in the game
//TODO: make toStrings for enum/classes or whatever
//TODO: add monster hides for armor crafting



//imports
package entities;

import items.*;
import items.Ore.OreItem;

//utilities
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class Monster {
	//TODO: rewrite this whole class for using MonsterEntity enum
	
	//VARIABLES
	private Player player;
	private MonsterEntity theMonster;
	private int currentHealth;
    private static final Random random = new Random(); // For random number generation
	
    //MONSTER LOOT TABLE
//[01]Plains...
	private static Item[] boarDrops = {new Ore(OreItem.IRON_ORE, 1), new Ore(OreItem.COPPER_ORE, 1)};
	private static double[] boarChances = {0.25, 0.25};
	
	private static Item[] slimeDrops = {new Ore(OreItem.IRON_ORE, 1)};
	private static double[] slimeChances = {0.5};
	
	private static Item[] snakeDrops = {new Ore(OreItem.COPPER_ORE, 1)};
	private static double[] snakeChances = {0.5};
	
//[02]Snow...
	
	
//[03]Desert...
			
			
//[04]Swamp...
			
			
//[05]Mountain...
			
			
//[06]Fire...
		

//[07]Jungle...
			
			
//[08]City...
			
			
//[09]Archipelago...
			
			
//[10]Cliffs...
	
	
	//end monster loot table
	
	
	
	//ENUMS
	public enum MonsterEntity { //name, isBoss, level, maxHealth, attack, defense, speed, critChance, critPercent, xpDrop, rhinDrop, itemDrops, dropChances
		
		//MONSTER LIST
		NULL("Null", false, 1, 1, 1, 1, 1, 0.1, 1.25, 0, 0, boarDrops, boarChances),
		
		//[01]Plains... (name, isBoss, level, maxHealth, attack, defense, speed, critChance, critPercent, xpDrop, rhinDrop, itemDrops, dropChances)
		BOAR("Boar", false, 1, 100, 10, 0, 100, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		SLIME("Slime", false, 1, 100, 10, 0, 50, 0.1, 1.25, 10, 10, slimeDrops, slimeChances),
		SNAKE("Snake", false, 1, 100, 10, 0, 150, 0.1, 1.25, 10, 10, snakeDrops, snakeChances),
		LIGHT_GOBLIN("Light Goblin", false, 10, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		HEAVY_GOBLIN("Heavy Goblin", false, 10, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		RED_CRAB("Red Crab", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		GREEN_CRAB("Green Crab", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		BLUE_CRAB("Blue Crab", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		KING_CRAB("King Crab", true, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		GOAT("Goat", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		RABBIT("Rabbit", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		WOLF("Wolf", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		FOX("Fox", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances),
		BEAR("Bear", false, 1, 100, 10, 10, 5, 0.1, 1.25, 10, 10, boarDrops, boarChances)
		
		//[02]Snow...
		
		
		//[03]Desert...
		
		
		//[04]Swamp...
		
		
		//[05]Mountain...
		
		
		//[06]Fire...
		
		
		//[07]Jungle...
		
		
		//[08]City...
		
		
		//[09]Archipelago...
		
		
		//[10]Cliffs...
		
		
		; //end monster list

		
		
		//VARIABLES
		private String name;
		private Boolean isBoss;
		private int level;
		private int maxHealth;
		private int attack;
		private int defense;
		private int speed;
		private double critChance;
		private double critDamage;
		private int xpDrop;
		private int rhinDrop;
		private Item[] itemDrops;
		private double[] itemChances;
		
		
		
		//HELPER METHODS
		
//CONSTRUCTORS
		MonsterEntity(String name, boolean isBoss, int level, int maxHealth, int attack, int defense, int speed, double critChance, double critDamage, int xpDrop, int rhinDrop,
				Item[] itemDrops, double[] itemChances) {
			
			this.name = name;
	        this.isBoss = isBoss;
	        this.level = level;
	        this.maxHealth = maxHealth;
	        this.attack = attack;
	        this.defense = defense;
	        this.speed = speed;
	        this.critChance = critChance;
	        this.critDamage = critDamage;
	        this.xpDrop = xpDrop;
	        this.rhinDrop = rhinDrop;
	        this.itemDrops = itemDrops;
	        this.itemChances = itemChances;
			
		}
		
//GETTERS
		public String getName() { return name; }
		public Boolean getIsBoss() { return isBoss; }
		public int getLevel() { return level; }
		public int getMaxHealth() { return maxHealth; }
		public int getAttack() { return attack; }
		public int getDefense() { return defense; }
		public int getSpeed() { return speed; }
		public double getCritChance() { return critChance; }
		public double getCritDamage() { return critDamage; }
		public int getXpDrop() { return xpDrop; }
		public int getRhinDrop() { return rhinDrop; }
		public Item[] getItemDrops() { return itemDrops; }
		public double[] getItemChances() { return itemChances; }
		
//SETTERS
		/*
		public void setName(String name) { this.name = name; }
		public void setIsBoss(Boolean isBoss) { this.isBoss = isBoss;}
		public void setLevel(int level) { this.level = level; }
		public void setMaxHealth(int maxHealth) { this.maxHealth = maxHealth; }
		public void setAttack(int attack) { this.attack = attack; }
		public void setDefense(int defense) { this.defense = defense; }
		public void setSpeed(int speed) { this.speed = speed; }
		public void setCritChance(double critChance) { this.critChance = critChance; }
		public void setCritDamage(double critDamage) { this.critDamage = critDamage; }
		public void setXpDrop(int xpDrop) { this.xpDrop = xpDrop; }
		public void setRhinDrop(int rhinDrop) { this.rhinDrop = rhinDrop; }
		public void setItemDrops(Item[] itemDrops) { this.itemDrops = itemDrops; }
		public void setItemChances(double[] itemChances) { this.itemChances = itemChances; }
		*/

	} //end MonsterEntity enum
	
    
    //METHODS
// Attack method
    public int attack() {
    	
        int damage = this.theMonster.getAttack();
        double theCritChance = this.theMonster.getCritChance();
        double theCritDamage = this.theMonster.getCritDamage();

        // Critical hit calculation
        if (random.nextDouble() <  theCritChance) {
            damage = (int) (damage * theCritDamage);
            System.out.println("Critical Hit!"); // For console output
        }
        
        if (damage < 1) {
            damage = 1; // Ensure at least 1 damage
        }

        return damage;
        
    }
    
    
// Method to determine item drops (in List<Item> form to match data type with inventory, should be fine...)
    public List<Item> calculateDrops() {

    	//array of items that successfully dropped, if item didnt drop, entry will be null
    	List<Item> droppedItems = new ArrayList<>();
        
    	//load theMonster drop stats
    	Item[] theItemDrops = this.theMonster.getItemDrops();
    	double[] theItemChances = this.theMonster.getItemChances();
        
    	//iterate through theItemDrops[]...
        for (int i = 0; i < theItemDrops.length; i++) {
        	
        	//drop chance check
            if (random.nextDouble() < theItemChances[i]) {
                droppedItems.add( theItemDrops[i].copy() );// Add a *copy* of the item to the droppedItems list, in position i
            }
            
        }
        
        return droppedItems;
        
    } //end calculateDrops()
  
    
    
    //HELPER METHODS
    
//CONSTRUCTORS
    public Monster(MonsterEntity theMonster) {
    	
    	this.theMonster = theMonster;
    	this.currentHealth = theMonster.getMaxHealth();
    	
    }
    
    public Monster() { //default constructor creates a nullMonster
		
    	this.theMonster = MonsterEntity.NULL;
    	this.currentHealth = 1;
    	
	}

//GETTERS
    public MonsterEntity getMonsterEntity() { return theMonster; }
    public int getCurrentHealth() { return currentHealth; }
    
//SETTERS
    public void setMonsterEntity(MonsterEntity theMonster) { this.theMonster = theMonster; }
    public void setCurrentHealth(int currentHealth) { this.currentHealth = currentHealth; }
    
//TOSTRING
    @Override
    public String toString() {
    	
        return "Monster{" +
                "name=" + getMonsterEntity().getName();
        
    }
    
} //end Monster class