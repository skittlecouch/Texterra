//Ore class, stores data about ore items, subclass of Item
//data: itemID, name, hardness, value, skillRequired, affinity, quantity

//TODO: general functionality
//TODO: add blacksmithing functionality
//TODO: create item list
//TODO: Ore descriptions????
//TODO: maybe add a null ore, idk item enums throw errors when theyre null and getters try to access them



//imports
package items;

import items.Weapon.WeaponItem;
import items.Weapon.WeaponType;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class Ore extends Item {
    
	//VARIABLES
    private OreItem oreItem; // Add the oreType field
    private int quantity; //ores stack

    
    
    //METHODS
    
    //implementation from Item class
    @Override
  	public Item copy() {
	  
    	return new Ore(getOreItem(), getQuantity());
      
    }
  
  
	
    //ENUMS
    public enum Affinity { //crafting affinity enum...
        WEAPON,
        ARMOR,
        INFUSION,
        FUEL,
        NONE
    }
    
    
    public enum OreItem { //Ore item List enum...
    	
    	//ORE ITEM LIST (itemID, name, hardness (maybe unused), default Value, skillRequired, affinity) [OreItem enum]
//[01]Plains...
    	IRON_ORE("iron_ore", "Iron Ore", 4, 5, 1, Ore.Affinity.ARMOR),
    	COPPER_ORE("copper_ore", "Copper Ore", 2, 5, 1, Ore.Affinity.WEAPON),
    	STEEL_ORE("steel_ore", "Steel Ore", 7, 30, 10, Ore.Affinity.ARMOR),
    	GOLD_ORE("gold_ore", "Gold Ore", 1, 200, 25, Ore.Affinity.INFUSION),
    	DIAMOND_ORE("diamond_ore", "Diamond Ore", 10, 500, 50, Ore.Affinity.INFUSION)
    	
//[02]Snow...
    	
    	
//[03]Desert...
    	
    	
//[04]Swamp...
    	
    	
//[05]Mountain...
    	
    	
//[06]Fire...
    	
    	
//[07]Jungle...
    	
    	
//[08]City...
    	
    	
//[09]Archipelago...
    	
    	
//[10]Cliffs...
    	
    	
    	; //end Ore Item List
    	
    	
    	//VARIABLES [OreItem enum]
        private final String id;
    	private final String name;
        private final int hardness;
        private final int value;
        private final int skillReq;
        private final Affinity oreAffinity;
        
        
        
        //METHODS [OreItem enum]
        public static OreItem fromId(String id) {
            for (OreItem ore : OreItem.values()) {
                if (ore.id.equals(id)) {
                    return ore;
                }
            }
            return null; // Or throw an exception
        }
        
        
        
        //HELPER METHODS [OreItem enum]
        
//CONSTRUCTORS [OreItem enum]
        OreItem(String id, String name, int hardness, int value, int skillReq, Affinity oreAffinity) {
        	
        	this.id = id;
        	this.name = name;
        	this.hardness = hardness;
        	this.value = value;
        	this.skillReq = skillReq;
        	this.oreAffinity = oreAffinity;
        	
        }
        
        OreItem(String id) {
        	
        	OreItem ore = OreItem.fromId(id);
        	this.id = id;
        	this.name = ore.getName();
        	this.hardness = ore.getHardness();
        	this.value = ore.getValue();
        	this.skillReq = ore.getSkillReq();
        	this.oreAffinity = ore.getOreAffinity();
        	
        }
        
//GETTERS [OreItem enum]
        public String getId() { return id; }
        public String getName() { return name; }
        public int getHardness() { return hardness; }
        public int getValue() { return value; }
        public int getSkillReq() { return skillReq; }
        public Affinity getOreAffinity() { return oreAffinity; }
        
    } //end [OreItem enum]
    
//END ENUMS
    
 
  
  	//HELPER METHODS
  
//CONSTRUCTORS
    public Ore(OreItem theItem, int quantity) {
    	
        super(theItem.getName(), "An Ore used for Blacksmithing", theItem.getValue()); //IF YOURE GOING TO ADD ORE DESCRIPTOINS DO IT HERE
        this.oreItem = theItem;
        this.quantity = quantity;
        
    }

    public Ore(OreItem theItem) {
    	
    	super(theItem.getName(), "An Ore used for Blacksmithing", theItem.getValue()); //IF YOURE GOING TO ADD ORE DESCRIPTOINS DO IT HERE
    	this.oreItem = theItem;
    	this.quantity = 1;
    	
    }
    
//GETTERS
    public OreItem getOreItem() { return oreItem; }
    public int getQuantity() { return quantity; }
    @Override //(Item)
    public String getItemType() { return "Ore"; }
    
//SETTERS
    public void setOreItem(OreItem oreItem) { this.oreItem = oreItem; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
//TOSTRING
    @Override //(Item)
    public String toString(){
        return "Ore: " + oreItem.getName();
    }

} //end Ore class