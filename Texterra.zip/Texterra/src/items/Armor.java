//class for the Armor items, stores their stats
//data: name, description, defense, strengthReq, speed, warmth, durability, qualityPercentage

//TODO: update MainScreenPanel stat trackers
//TODO: add warmth functionality (does something??? maybe affects regen, speed, and crits)
//TODO: add strength functionality (equip requirement)
//TODO: add durability functionality (ticks down once per attack cycle)
//TODO: add defense funcitonality (divides damage applied, health should be an int though)
//TODO: add speed functionality (higher speed attacks first, if your speed is 2x the monster's speed, you attack twice per attack cycle, 3x is triple etc.)
//TODO: add quality functionality (detriment to durability, defense, value)
//TODO: maybe add crit modifiers to weapons and armor? and other stat boosts too, especially for higher level gear
//TODO: create item list
//TODO: balance item stats (do last)

//note: defaultStats[] is a double array just because of quality percentage, but the getters all cast to ints, should be fine



//imports
package items;

import items.Weapon.WeaponItem;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class Armor extends Item {

	//VARIABLES
	private ArmorItem theArmor;
    private int warmth; //in blacksmithing, hide items can be applied to armor during crafting
    private int durability;
    private double qualityPercentage;
    
//DEFAULT STATS VARIABLES (warmth, durability, qualityPercentage, defaultValue)
    private static double[] ironArmorStats = {0, 100, 1, 200};
    private static double[] copperArmorStats = {0, 100, 1, 150};
    private static double[] steelArmorStats = {0, 100, 1, 100};
    private static double[] goldArmorStats = {0, 100, 1, 100};
    private static double[] diamondArmorStats = {0, 100, 1, 100};
    
    
    
    //ENUMS
    public enum ArmorItem { //(name, description, defense, strengthReq, speed, defaultStats)
    	
    	//ARMOR ITEM LIST
    	NULL("null_armor", "Null Armor", "[Armor Description]", 0, 0, 0, ironArmorStats),
//[01]Plains...
    	IRON_ARMOR("iron_armor", "Iron Armor", "[Armor Description]", 10, 10, 10, ironArmorStats),
    	COPPER_ARMOR("copper_armor", "Copper Armor", "[Armor Description]", 10, 10, 10, copperArmorStats),
    	STEEL_ARMOR("steel_armor", "Steel Armor", "[Armor Description]", 10, 10, 10, steelArmorStats),
    	GOLD_ARMOR("gold_armor", "Gold Armor", "[Armor Description]", 10, 10, 10, goldArmorStats),
    	DIAMOND_ARMOR("diamond_armor", "Diamond Armor", "[Armor Description]", 10, 10, 10, diamondArmorStats)
    	
//[02]Snow...
    	
    	
//[03]Desert...
    	    	
    	    	
//[04]Swamp...
    	    	
    	    	
//[05]Mountain...
    	    	
    	    	
//[06]Fire...
    	    	
    	    	
//[07]Jungle...
    	    	
    	    	
//[08]City...
    	    	
    	    	
//[09]Archipelago...
    	    	
    	    	
//[10]Cliffs...
    	
    	
    	; //end Armor Item List
    	
    	
    	
    	//VARIABLES [ArmorItem enum]
    	private final String id;
    	private final String name;
    	private final String description;
    	private final int defense;
    	private final int strengthReq;
    	private final int speed;
    	private final double[] defaultStats;
    	
    	
    	
    	//METHODS
    	public static ArmorItem fromId(String id) {
            for (ArmorItem armor : ArmorItem.values()) {
                if (armor.id.equals(id)) {
                    return armor;
                }
            }
            return null; // Or throw an exception
        }
    	
    	
    	
    	//HELPER METHODS [ArmorItem enum]
    	
//CONSTRUCTORS [ArmorItem enum]
    	ArmorItem(String id, String name, String description, int defense, int strengthReq, int speed, double[] defaultStats) {
    		
    		this.id = id;
    		this.name = name;
    		this.description = description;
    		this.defense = defense;
    		this.strengthReq = strengthReq;
    		this.speed = speed;
    		this.defaultStats = defaultStats;
    		
    	}
    	
    	ArmorItem(String id) {
    		
    		ArmorItem armor = ArmorItem.fromId(id);
            
            this.id = id;
            this.name = armor.getName();
    		this.description = armor.getDescription();
    		this.defense = armor.getDefense();
    		this.strengthReq = armor.getStrengthReq();
    		this.speed = armor.getSpeed();
    		this.defaultStats = armor.getDefaultStats();
    		
    		
    	}
    	
//GETTERS [ArmorItem enum]
        public ArmorItem getArmorItem() {
        	ArmorItem armor = ArmorItem.fromId(id);
        	return armor;
        }
    	public String getId() { return id; }
    	public String getName() { return name; }
    	public String getDescription() { return description; }
    	public int getDefense() { return defense; }
    	public int getStrengthReq() { return strengthReq; }
    	public int getSpeed() { return speed; }
    	public double[] getDefaultStats() { return defaultStats; }
    	public int getWarmth() { return (int) defaultStats[0]; }
    	public int getDurability() { return (int) defaultStats[1]; }
    	public double getQualityPercentage() { return defaultStats[2]; }
    	public int getValue() { return (int) defaultStats[3]; }
    	
    	
    	
    } //end ArmorItem Enum
    
    //END ENUMS
    
    
    
    //METHODS
    @Override //from Item class
    public String getItemType() {
        return "Armor";
    }

    @Override //from Item class
    public Item copy() {
        return new Armor(getArmorItem(), getWarmth(), getDurability(), getQualityPercentage(), getValue());
    }
    
    
    
    //HELPER METHODS
    
//CONSTRUCTORS
    public Armor(ArmorItem theArmor, int warmth, int durability, double qualityPercentage, int value) {
    	
    	super(theArmor.getName(), "[Armor Description]", value);
        this.theArmor = theArmor;
        this.warmth = warmth;
        this.durability = durability;
        this.qualityPercentage = qualityPercentage;
        
    }
    
    public Armor(ArmorItem theArmor) {
    	
    	super(theArmor.getName(), "[Armor Description]", theArmor.getValue());
        this.theArmor = theArmor;
        this.warmth = theArmor.getWarmth();
        this.durability = theArmor.getDurability();
        this.qualityPercentage = theArmor.getQualityPercentage();
        
    }
    
    public Armor() { //null Armor constructor
    	
    	super("None", "this is such a bruh momentum", 0);
    	this.theArmor = ArmorItem.NULL;
        this.warmth = 0;
        this.durability = 0;
        this.qualityPercentage = 1;
    	
    }

//GETTERS
    public ArmorItem getArmorItem() { return theArmor; }
    public int getWarmth() { return warmth; }
    public int getDurability() { return durability; }
    public double getQualityPercentage() { return qualityPercentage; }
 
//SETTERS
    public void setWarmth(int warmth) { this.warmth = warmth; }
    public void setDurability(int durability) { this.durability = durability; }
    public void setQualityPercentage(double qualityPercentage) { this.qualityPercentage = qualityPercentage; }

//TOSTRING
    @Override
    public String toString() {
        return "Armor: " + theArmor.getName();
    }
    
} //end Armor class