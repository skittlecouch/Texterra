//general item class, things like food potions and weapons are subclasses of Item

//TODO: Class for hide items
//TODO: Class for ingredient items
//TODO: Class for seed items

//note: COPY METHOD????


//imports
package items;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public abstract class Item {
	
	//VARIABLES
    private String name;
    private String description;
    private int value;
    private int itemID;
    private static int nextItemID = 0;

    
    
    //METHODS
 // Crucial: Add a copy() method to create copies of items
    public abstract Item copy();
    
    
    
    //HELPER METHODS
    
    //CONSTRUCTORS
    public Item(String name, String description, int value) {
        this.name = name;
        this.description = description;
        this.value = value;
        this.itemID = nextItemID++;
    }

    
    
    //GETTERS
    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getValue() { return value; }
    public int getItemID() { return itemID; }

    public abstract String getItemType();
    
    
    
    //SETTERS
    public void setName(String name) { this.name = name; }
    public void setDescription(String description) { this.description = description; }
    public void setValue(int value) { this.value = value; }
    
    
    public String toString() {
        return "Item: " + name;
    }
    
} //end Item class