//FLOOR NAMES



package game;



public enum WorldName {
	
    // Enum constants, with names, display names, and level requirements.
    PLAINS("[01]Plains", 1),
    SNOW("[02]Snow", 2),
    DESERT("[03]Desert", 3),
    SWAMP("[04]Swamp", 4),
    MOUNTAIN("[05]Mountain", 5),
    FIRE("[06]Fire", 6),
    JUNGLE("[07]Jungle", 7),
    CITY("[08]City", 8),
    ARCHIPELAGO("[09]Archipelago", 9),
    CLIFFS("[10]Cliffs", 10),
    // Add other worlds here if you make them
    ;

    private final String id;        // Internal ID (e.g., "[01]Plains")
    private final int orderValue; //sorts them in order, can compare less than and greater than given floor, used to check if floor is unlocked based on player.getUnlockedWorld()

    // Constructors
    WorldName(String id, int orderValue) {
        this.id = id;
        this.orderValue = orderValue;
    }
    
    WorldName(String id) {
    	
        WorldName theFloor = fromId(id);
        
        this.id = id;
        this.orderValue = theFloor.getOrderValue();
        
    }
    
    WorldName(int orderValue) {
    	
        WorldName theFloor = fromOrderValue(orderValue);
        
        this.orderValue = orderValue;
        this.id = theFloor.getId();
        
    }

    // Getters
    public String getId() {
        return id;
    }

    public int getOrderValue() {
        return orderValue;
    }
    
    // Method to get a WorldName by its ID
    public static WorldName fromId(String id) {
    	
        for (WorldName floor : WorldName.values()) {
            if (floor.id.equals(id)) {
                return floor;
            }
        }
        
        return null; // Or throw an exception if an ID is not found
        
    }
    
    //method to get WorldName by its OrderValue
    public static WorldName fromOrderValue(int orderValue) {
    	
        for (WorldName floor : WorldName.values()) {
            if (floor.getOrderValue() == orderValue) {
                return floor;
            }
        }
        
        return null; // Or throw an exception if an ID is not found
        
    }
    
}