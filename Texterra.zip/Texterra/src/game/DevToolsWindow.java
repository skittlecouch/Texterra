//dev tool window to show player stats to developer, helps with debugging
//TODO: maybe error codes??? dont know if i throw enough exceptions for that tho...



//imports
package game;

import screens.ui.MainScreenPanel;
import screens.ui.WorldSelectScreenPanel;
import entities.Player;
import game.WorldName;
import items.Item;



//utilities
import javax.swing.*;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class DevToolsWindow extends JFrame {

	//VARIABLES
    private JTextArea statsArea;
    private Texterra mainFrame; //keep a reference to the main texterra frame
    private Player player;
    
    
    //METHODS
    public void updateStats() {
    	
        // Get data from MainScreenPanel (using getters)
        MainScreenPanel mainScreen = mainFrame.getMainScreenPanel();
        StringBuilder sb = new StringBuilder();
        

        sb.append("--- Player Stats ---\n");
        sb.append("Name: ").append(mainScreen.getPlayerName()).append("\n"); // Example - add getName()
        sb.append("Level: ").append(mainScreen.getLevel()).append("\n");
        sb.append("Health: ").append(mainScreen.getHealth()).append(" / ").append(mainScreen.getMaxHealth()).append("\n");
        sb.append("XP: ").append(mainScreen.getXP()).append(" / ").append(mainScreen.getXPNeeded()).append("\n");
        sb.append("Rhin: ").append(mainScreen.getRhin()).append("\n");
        sb.append("Strength: ").append(mainScreen.getStrength()).append("\n"); // Assuming you have a getStrength() method
        sb.append("Defense: ").append(mainScreen.getDefense()).append("\n"); // Assuming you have a getDefense() method
        sb.append("Speed: ").append(mainScreen.getSpeed()).append("\n"); // Assuming you have a getSpeed()
        sb.append("Crit Chance: ").append(mainScreen.getCritChance()).append("\n");
        sb.append("Crit Percent: ").append(mainScreen.getCritPercent()).append("\n");
        sb.append("Cooking Skill: ").append(mainScreen.getCookingSkill()).append("\n");
        sb.append("Blacksmithing Skill: ").append(mainScreen.getBlacksmithingSkill()).append("\n");
        sb.append("Brewing Skill: ").append(mainScreen.getBrewingSkill()).append("\n");
        sb.append("Farming Skill: ").append(mainScreen.getFarmingSkill()).append("\n");
        sb.append("Unlocked World: ").append(mainScreen.getUnlockedWorld().getId()).append("\n");

        sb.append("\n--- Equipped Items ---\n");
        if (mainScreen.getEquippedWeapon() != null) {
            sb.append("Weapon: ").append(mainScreen.getEquippedWeapon().getName()).append("\n");
        } else {
            sb.append("Weapon: None\n");
        }
         if (mainScreen.getEquippedArmor() != null) {
            sb.append("Armor: ").append(mainScreen.getEquippedArmor().getName()).append("\n"); //need to add getEquippedArmor
        } else {
            sb.append("Armor: None\n");
        }

        sb.append("\n--- Inventory ---\n");
        for (Item item : mainScreen.getInventory()) {
            sb.append(item.toString()).append("\n"); // Use the toString() method of your item classes
        }

        statsArea.setText(sb.toString()); // Update the text area

    } //end updateStats() method
    
    
    
    //HELPER METHODS
    
    //CONSTRUCTORS
    public DevToolsWindow(Texterra mainFrame) {
    	
        this.mainFrame = mainFrame;
        this.player = mainFrame.getMainScreenPanel().getPlayer(); //loads player
        
        setTitle("Dev Tools");
        setSize(1000, 600); // Adjust size as needed
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Important: Dispose on close
        
        
        //contains stats pane and cheats panel
        JPanel devWindow = new JPanel();
        devWindow.setLayout(new BorderLayout());
        devWindow.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10)); //N, W, S, E (but why though)
        
        
        //statsArea (NORTH)
        statsArea = new JTextArea();
        statsArea.setEditable(false); // Read-only
        JScrollPane scrollPane = new JScrollPane(statsArea);
        
        
//add cheats here
        //cheatsPanel (SOUTH)
        JPanel cheatsPanel = new JPanel();
        
        JPanel levelPanel = new JPanel();
        JPanel rhinPanel = new JPanel();
        JPanel worldPanel = new JPanel();
        //other cheats panels...
        
        
        cheatsPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        
        levelPanel.setLayout(new GridLayout(2,1)); //rows, columns
        levelPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        
        rhinPanel.setLayout(new GridLayout(2,1)); //rows, columns
        rhinPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        
        worldPanel.setLayout(new GridLayout(2,1)); //rows, columns
        worldPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        
        //other cheats panels...
        
        
        JLabel levelLabel = new JLabel("Level:");
        JLabel rhinLabel = new JLabel("Rhin: ");
        JLabel worldLabel = new JLabel("Unlocked World (int):");
        //other cheats labels...
        
        TextArea levelArea = new TextArea(1, 20);
        TextArea rhinArea = new TextArea(1, 20);
        TextArea worldArea = new TextArea(1, 20);
        //other cheat text areas...
        
        
        JButton applyButton = new JButton("Apply");
        applyButton.addActionListener(e -> {
        	
        	
        	//read inputs
        	String levelText = levelArea.getText();
        	String rhinText = rhinArea.getText();
        	String worldText = worldArea.getText();
        	//other cheat items...
        	
        	int level;
    		int rhin;
    		int world;
    		
        	//parse inputs
        	try {
        		
        		if (!levelText.isBlank()) {
        			level = Integer.parseInt(levelText);
        			player.setLevel(level);
        			player.updateStatsOnLevel(level);
        			levelArea.setText("");
        		}
        		
        		if (!rhinText.isBlank()) {
        			rhin = Integer.parseInt(rhinText);
            		player.setRhin(rhin);
            		rhinArea.setText("");
        		}
        		
        		if (!worldText.isBlank()) {
        			world = Integer.parseInt(worldText);
        			
        			if (world <= 10) {
            		player.setUnlockedWorld(WorldName.fromOrderValue(world));
            		worldArea.setText("");
        			} else {
        				worldArea.setText("");
        				throw new NumberFormatException("Error");
        				
        			}
            		
        		}
        		
        		//other cheats...
        		
        		
        		//update stats everywhere
        		updateStats(); //updates stats list in dev window
        		mainFrame.getMainScreenPanel().refreshStats(); //updates stats in main menu screen
        		mainFrame.getMainScreenPanel().refreshAreaAccess(); //updates area access from new level count
        		mainFrame.getWorldSelectScreenPanel().refreshWorldSelect(); //refreshes world access from new unlockedWorld
        		mainFrame.getShopScreenPanel().refreshStats(); //updates rhin tracker in shop
        		
        	} catch (NumberFormatException ex) {
        		levelArea.setText("Error");
        	}
        	
        });
        
        
        //add the nonsense
        //level cheat
        levelPanel.add(levelLabel);
        levelPanel.add(levelArea);
        
        
        //rhin cheat
        rhinPanel.add(rhinLabel);
        rhinPanel.add(rhinArea);
        
        
        //Unlocked world cheat
        worldPanel.add(worldLabel);
        worldPanel.add(worldArea);
        //other cheats...
        
        
        //cheats panel
        cheatsPanel.add(levelPanel);
        cheatsPanel.add(rhinPanel);
        cheatsPanel.add(worldPanel);
        //other cheats...
        
        
        //dev window
        devWindow.add(scrollPane, BorderLayout.NORTH);
        devWindow.add(cheatsPanel, BorderLayout.CENTER);
        devWindow.add(applyButton, BorderLayout.SOUTH);
        
        
        
        add(devWindow);
        
        
        
        // Add a window listener to handle closing
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                // Optionally add some behavior when the window is closed.
                // For example, you might want to null out the devToolsWindow
                // reference in SettingsScreenPanel.  This prevents a memory leak.
            }
        });
        
        updateStats(); //Update stats upon opening
        
    } //end DevToolsWindow() constructor

} //end DevToolsWindow class