package screens.worlds.floor10cliffs;

public class CliffsPanel {

}
