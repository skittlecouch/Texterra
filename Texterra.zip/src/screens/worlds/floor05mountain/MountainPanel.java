package screens.worlds.floor05mountain;

public class MountainPanel {

}
