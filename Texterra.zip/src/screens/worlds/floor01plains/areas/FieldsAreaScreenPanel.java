//Fields area, home to boars slimes and snakes



//imports
package screens.worlds.floor01plains.areas;

import game.BaseScreenPanel;
import game.Texterra;
import items.Item;
import items.Ore;
import screens.worlds.floor01plains.PlainsPanel;
import entities.Monster;
import screens.ui.BattleScreenPanel;



//utilities
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.ArrayList;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class FieldsAreaScreenPanel extends BaseScreenPanel {
	
	//VARIABLES

//MOB DROPS
	List<Item> boarDrops = new ArrayList<>();
	List<Double> boarDropChances = new ArrayList<>();
	
	List<Item> slimeDrops = new ArrayList<>();
	List<Double> slimeDropChances = new ArrayList<>();
	
	List<Item> snakeDrops = new ArrayList<>();
	List<Double> snakeDropChances = new ArrayList<>();
	
	Ore theOre;
	
	
	//TODO set all these mob values as const variables imported from balance sheet file i can edit all in one place
//MOBS
	//name, isBoss, level, health, attack, defense, speed, critChance, critPercent, xpDrop, rhinDrop, itemDrops, dropChances
	Monster boar = new Monster("Boar", false, 1, 100, 5, 5, 5, 0.10, 1.25, 10, 10, boarDrops, boarDropChances);
	Monster slime = new Monster("Slime", false, 1, 200, 3, 7, 3, 0.10, 1.25, 10, 10, slimeDrops, slimeDropChances);
	Monster snake = new Monster("Snake", false, 1, 50, 7, 3, 7, 0.10, 1.25, 10, 10, snakeDrops, snakeDropChances);
	
	
	//CONSTRUCTORS
    public FieldsAreaScreenPanel(Texterra mainFrame) {
    	
        super(mainFrame);
        setLayout(new BorderLayout()); // Example: 3 columns for monsters
        setBorder(BorderFactory.createEmptyBorder(450, 0, 0, 50));

        
        JPanel battlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        
        JButton boarButton = new JButton("Fight Boars");
        JButton slimeButton = new JButton("Fight Slimes");
        JButton snakeButton = new JButton("Fight Snakes");


        boarButton.addActionListener(e -> createAndShowBattleScreen(boar)); //boar
        slimeButton.addActionListener(e -> createAndShowBattleScreen(slime)); //slime
        snakeButton.addActionListener(e -> createAndShowBattleScreen(snake)); //snake

        
        battlePanel.add(boarButton);
        battlePanel.add(slimeButton);
        battlePanel.add(snakeButton);
        
        
        add(battlePanel, BorderLayout.CENTER);
        
        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> mainFrame.showScreen(Texterra.WILDS01_SCREEN));
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);
        
        
    }

    
    
    private void createAndShowBattleScreen(Monster battleMonster) {
    	
        BattleScreenPanel battleScreen = new BattleScreenPanel(getMainFrame(), battleMonster); // Pass MONSTER
        getMainFrame().getCardPanel().add(battleScreen, Texterra.BATTLE_SCREEN); // Use constant
        getMainFrame().showScreen(Texterra.BATTLE_SCREEN);
        
}
    
} //end FieldsAreaScreenPanel class