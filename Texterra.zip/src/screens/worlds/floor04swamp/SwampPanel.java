package screens.worlds.floor04swamp;

public class SwampPanel {

}
