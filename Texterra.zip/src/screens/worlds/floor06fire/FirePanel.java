package screens.worlds.floor06fire;

public class FirePanel {

}
