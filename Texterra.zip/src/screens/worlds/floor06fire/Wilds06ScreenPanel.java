package screens.worlds.floor06fire;

public class Wilds06ScreenPanel {

}
