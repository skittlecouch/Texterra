//world selection screen, to choose between various worlds, you must beat the boss of the previous floor's dungeon tower before you can move on to the next
//TODO: DEAL WITH THE WILDS01 WILDS02... BS, wildsCardPanel in Wilds01Screen class
//TODO: world buttons are disabled based on player unlocked worlds
//TODO: world panels switched to when button gets clicked
//TODO: if you add worlds past the floors, add meta buttons for worlds like {b}verse etc. that opens floor select
//TODO: in world button listener, dont switch to main, switch to floor specific screens. mainFrame.showScreen(Texterra.MAIN_SCREEN);



//imports
package screens.ui;

import game.BaseScreenPanel;
import game.Texterra;
import game.WorldName;
import entities.Player;



import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class WorldSelectScreenPanel extends BaseScreenPanel {
	
	private Player player;
	
	private JButton worldButton;
	private JPanel worldsPanel;
	
	private String[] worldNames = {
            "[01]Plains", "[02]Snow", "[03]Desert", "[04]Swamp", "[05]Mountain",
            "[06]Fire", "[07]Jungle", "[08]City", "[09]Archipelago", "[10]Cliffs"
    };
	
	public void refreshWorldSelect() {
		
		worldsPanel.removeAll();
		
		for (String worldName : worldNames) { //iterates through worldNames[]
        	
        	WorldName theWorld = WorldName.fromId(worldName); //sets WorldName enum based on worldNames[]
        	
        	//create button
            worldButton = new JButton(worldName);
            worldButton.addActionListener(new WorldButtonListener(theWorld, mainFrame));
            
            //unlocked world check
            worldButton.setEnabled( theWorld.getOrderValue() <= player.getUnlockedWorld().getOrderValue() );
            
            //add button
            worldsPanel.add(worldButton);
            
        }
		
		worldsPanel.revalidate();
		worldsPanel.repaint();
		
	}
	
	//CONSTRUCTORS
    public WorldSelectScreenPanel(Texterra mainFrame) {
    	
        super(mainFrame);
        this.player = mainFrame.getMainScreenPanel().getPlayer(); //load player
        setLayout(new BorderLayout());

        
        // --- Top Panel ---
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("World Select");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        topPanel.add(titleLabel);
        add(topPanel, BorderLayout.NORTH);

        
        // --- Center Panel ---
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

		worldsPanel = new JPanel();
		worldsPanel.setLayout(new GridLayout(0, 2, 10, 10));
        
        refreshWorldSelect();
        
        centerPanel.add(worldsPanel, BorderLayout.CENTER);
        

        add(centerPanel, BorderLayout.CENTER);

        
        // --- Bottom Panel ---
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backButton = new JButton("Back");
        
        backButton.addActionListener(e -> mainFrame.showScreen(Texterra.MAIN_SCREEN));
        
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);
        
    }

    
    
    // --- Inner Class for World Button Listener ---
    private class WorldButtonListener implements ActionListener {
    	
    	//VARIABLES
        private WorldName theWorld;
        private Texterra mainFrame;
        
      //METHODS
        @Override
        public void actionPerformed(ActionEvent e) {
        	
            mainFrame.getMainScreenPanel().setCurrentWorld( theWorld );
            mainFrame.showScreen(Texterra.MAIN_SCREEN); //switch to world specific screens------------------------------------------------------------------------------
        }

        //CONSTRUCTORS
        public WorldButtonListener(WorldName theWorld, Texterra mainFrame) {
            this.theWorld = theWorld;
            this.mainFrame = mainFrame;
        }

    } //end WorldButtonListener subclass
    
} //end WorldSelectScreenPanel class
