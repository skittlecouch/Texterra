//weapon class, stores data about weapon items, subclass of Item
//TODO: add strength functionality
//TODO: add durability functionality
//TODO: add speed functionality
//TODO: add quality functionality
//TODO: balance item stats (do last)
//TODO: maybe add crit modifiers to weapons and armor?
//TODO: create item list
//TODO: ctrl+f 'descriptionNeeded' and add item descriptions



//imports
package items;



//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



public class Weapon extends Item {

	//VARIABLES
	private WeaponItem theWeapon;
    private int damage;
    private int speed;
    private int durability;
    private double qualityPercentage;
    private int value;
    
    
    
//DEFAULT STATS VARIABLES (damage, speed, durability, qualityPercentage, value) [oh boy long AF pt. 1]
    
    	//[01]Plains weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
/* other weapons based on ores (will do later ffs)
		//[02]Snow weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[03]Desert weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[04]Swamp weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[05]Mountain weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[06]Fire weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[07]Jungle weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[08]City weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[09]Archipelago weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
	
		//[10]Cliffs weapons
	private static double[] ironGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] ironLongswordStats = {1, 2, 3, 4, 5};
	private static double[] ironDaggerStats = {1, 2, 3, 4, 5};
	private static double[] ironRapierStats = {1, 2, 3, 4, 5};
	private static double[] ironBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] copperGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] copperLongswordStats = {1, 2, 3, 4, 5};
	private static double[] copperDaggerStats = {1, 2, 3, 4, 5};
	private static double[] copperRapierStats = {1, 2, 3, 4, 5};
	private static double[] copperBattleAxeStats = {1, 2, 3, 4, 5};

	private static double[] steelGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] steelLongswordStats = {1, 2, 3, 4, 5};
	private static double[] steelDaggerStats = {1, 2, 3, 4, 5};
	private static double[] steelRapierStats = {1, 2, 3, 4, 5};
	private static double[] steelBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] goldGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] goldLongswordStats = {1, 2, 3, 4, 5};
	private static double[] goldDaggerStats = {1, 2, 3, 4, 5};
	private static double[] goldRapierStats = {1, 2, 3, 4, 5};
	private static double[] goldBattleAxeStats = {1, 2, 3, 4, 5};
	
	private static double[] diamondGreatswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondLongswordStats = {1, 2, 3, 4, 5};
	private static double[] diamondDaggerStats = {1, 2, 3, 4, 5};
	private static double[] diamondRapierStats = {1, 2, 3, 4, 5};
	private static double[] diamondBattleAxeStats = {1, 2, 3, 4, 5};
	
*/
	
	
	//ENUMS
// Enum for Weapon Types
    public enum WeaponType {
        LONGSWORD,
        DAGGER,
        GREATSWORD,
        RAPIER,
        BATTLEAXE
    }
    
//Enum for WeaponItems
    public enum WeaponItem {
    	
    	//TYPES
//weapon list..... this gonna be long af :(
    	
    		//[01]Plains weapon types
    	IRON_GREATSWORD("iron_greatsword", "Iron Greatsword", "A heavy two-handed sword.", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        IRON_LONGSWORD("iron_longsword", "Iron Longsword", "A versatile one-handed sword.", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        IRON_DAGGER("iron_dagger", "Iron Dagger", "A quick and deadly dagger.", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        IRON_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        IRON_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
/* OTHER WEAPONS BASED ON ORES, WILL DO LATER FFS
		COPPER_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        COPPER_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        COPPER_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        COPPER_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        COPPER_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        STEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        STEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        STEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        STEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        STEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        GOLD_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        GOLD_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        GOLD_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        GOLD_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        GOLD_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        DIAMOND_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        DIAMOND_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        DIAMOND_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        DIAMOND_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        DIAMOND_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),


			//[02]Snow weapon types
		COAL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        COAL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        COAL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        COAL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        COAL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		FREEZITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        FREEZITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        FREEZITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        FREEZITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        FREEZITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        BLUESTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        BLUESTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        BLUESTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        BLUESTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        BLUESTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        CRYSTALIZED_ICE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        CRYSTALIZED_ICE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        CRYSTALIZED_ICE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        CRYSTALIZED_ICE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        CRYSTALIZED_ICE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        TUNDRITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        TUNDRITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        TUNDRITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        TUNDRITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        TUNDRITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[03]Desert weapon types
        TURQUOISE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        TURQUOISE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        TURQUOISE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        TURQUOISE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        TURQUOISE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		FEROMINIUM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        FEROMINIUM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        FEROMINIUM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        FEROMINIUM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        FEROMINIUM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        SUNSTONE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        SUNSTONE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        SUNSTONE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        SUNSTONE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        SUNSTONE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        GOLDSTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        GOLDSTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        GOLDSTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        GOLDSTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        GOLDSTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        FLAMEHART_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        FLAMEHART_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        FLAMEHART_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        FLAMEHART_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        FLAMEHART_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[04]Swamp weapon types
        MOONSTONE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        MOONSTONE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        MOONSTONE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        MOONSTONE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        MOONSTONE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		FOGROCK_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        FOGROCK_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        FOGROCK_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        FOGROCK_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        FOGROCK_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        DEW_CRYSTAL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        DEW_CRYSTAL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        DEW_CRYSTAL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        DEW_CRYSTAL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        DEW_CRYSTAL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        MOSSIUM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        MOSSIUM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        MOSSIUM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        MOSSIUM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        MOSSIUM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        MUKTITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        MUKTITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        MUKTITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        MUKTITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        MUKTITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        YGGDRA_ROOT_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        YGGDRA_ROOT_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        YGGDRA_ROOT_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        YGGDRA_ROOT_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        YGGDRA_ROOT_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[05]Mountain weapon types
        DEEPSLATE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        DEEPSLATE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        DEEPSLATE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        DEEPSLATE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        DEEPSLATE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		MITHRIL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        MITHRIL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        MITHRIL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        MITHRIL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        MITHRIL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        LAPIUM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        LAPIUM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        LAPIUM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        LAPIUM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        LAPIUM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        TEKTITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        TEKTITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        TEKTITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        TEKTITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        TEKTITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        SKY_SAPPHIRE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        SKY_SAPPHIRE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        SKY_SAPPHIRE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        SKY_SAPPHIRE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        SKY_SAPPHIRE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[06]Fire weapon types
        CINNABAR_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        CINNABAR_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        CINNABAR_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        CINNABAR_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        CINNABAR_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		BRIMSTONE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        BRIMSTONE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        BRIMSTONE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        BRIMSTONE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        BRIMSTONE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        MAGMITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        MAGMITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        MAGMITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        MAGMITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        MAGMITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        REDSTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        REDSTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        REDSTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        REDSTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        REDSTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        BLOOD_RUBY_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        BLOOD_RUBY_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        BLOOD_RUBY_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        BLOOD_RUBY_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        BLOOD_RUBY_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[07]Jungle weapon types
        VERDITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        VERDITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        VERDITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        VERDITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        VERDITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		FERRA_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        FERRA_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        FERRA_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        FERRA_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        FERRA_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        TIGERITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        TIGERITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        TIGERITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        TIGERITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        TIGERITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        TERRION_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        TERRION_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        TERRION_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        TERRION_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        TERRION_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        LEAFSTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        LEAFSTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        LEAFSTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        LEAFSTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        LEAFSTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        MISTIMITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        MISTIMITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        MISTIMITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        MISTIMITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        MISTIMITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        EMERALD_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        EMERALD_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        EMERALD_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        EMERALD_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        EMERALD_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[08]City weapon types
        LECTRICITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        LECTRICITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        LECTRICITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        LECTRICITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        LECTRICITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		RACCIUM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        RACCIUM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        RACCIUM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        RACCIUM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        RACCIUM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        NEON_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        NEON_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        NEON_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        NEON_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        NEON_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        PURPLESTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        PURPLESTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        PURPLESTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        PURPLESTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        PURPLESTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        XENITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        XENITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        XENITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        XENITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        XENITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        AMETHYST_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        AMETHYST_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        AMETHYST_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        AMETHYST_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        AMETHYST_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        

        	//[09]Archipelago weapon types
        TROPICITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        TROPICITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        TROPICITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        TROPICITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        TROPICITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		SEASTONE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        SEASTONE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        SEASTONE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        SEASTONE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        SEASTONE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        HYDROX_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        HYDROX_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        HYDROX_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        HYDROX_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        HYDROX_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        AQUASTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        AQUASTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        AQUASTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        AQUASTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        AQUASTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        CLOUD_CRYSTAL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        CLOUD_CRYSTAL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        CLOUD_CRYSTAL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        CLOUD_CRYSTAL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        CLOUD_CRYSTAL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        KLYPSITE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        KLYPSITE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        KLYPSITE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        KLYPSITE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        KLYPSITE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        
        	//[10]Cliffs Weapon types
        SILVER_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        SILVER_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        SILVER_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        SILVER_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        SILVER_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
		BRONZE_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        BRONZE_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        BRONZE_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        BRONZE_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        BRONZE_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        CRYSTALIZED_MOONBEAM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        CRYSTALIZED_MOONBEAM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        CRYSTALIZED_MOONBEAM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        CRYSTALIZED_MOONBEAM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        CRYSTALIZED_MOONBEAM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        DELTASTAR_FRAGMENT_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        DELTASTAR_FRAGMENT_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        DELTASTAR_FRAGMENT_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        DELTASTAR_FRAGMENT_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        DELTASTAR_FRAGMENT_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        WHITESTEEL_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        WHITESTEEL_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        WHITESTEEL_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        WHITESTEEL_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        WHITESTEEL_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        CRYSTALIZED_SUNBEAM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        CRYSTALIZED_SUNBEAM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        CRYSTALIZED_SUNBEAM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        CRYSTALIZED_SUNBEAM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        CRYSTALIZED_SUNBEAM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats),
        
        PENTIUM_GREATSWORD("iron_greatsword", "Iron Greatsword", "descriptionNeeded", 10, Weapon.WeaponType.GREATSWORD, ironGreatswordStats),
        PENTIUM_LONGSWORD("iron_longsword", "Iron Longsword", "descriptionNeeded", 5, Weapon.WeaponType.LONGSWORD, ironLongswordStats),
        PENTIUM_DAGGER("iron_dagger", "Iron Dagger", "descriptionNeeded", 2, Weapon.WeaponType.DAGGER, ironDaggerStats),
        PENTIUM_RAPIER("iron_rapier", "Iron Rapier", "descriptionNeeded", 2, Weapon.WeaponType.RAPIER, ironRapierStats),
        PENTIUM_BATTLEAXE("iron_battleaxe", "Iron Battle Axe", "descriptionNeeded", 2, Weapon.WeaponType.BATTLEAXE, ironBattleAxeStats)
        
*/  
        
        
        ;
    	
    	
    	
    	//VARIABLES
    	private final String id;
        private final String name;
        private final String description;
        private final int strengthReq;
        private final WeaponType weaponType;
        private double[] defaultStats;
        

        
        //METHODS
        public static WeaponItem fromId(String id) {
            for (WeaponItem weapon : WeaponItem.values()) {
                if (weapon.id.equals(id)) {
                    return weapon;
                }
            }
            return null; // Or throw an exception
        }
    	

        
        //HELPER METHODS
        
//CONSTRUCTORS
        WeaponItem(String id, String name, String description, int strengthReq, WeaponType weaponType, double[] defaultStats) {
        	
            this.id = id;
            this.name = name;
            this.description = description;
            this.strengthReq = strengthReq;
            this.weaponType = weaponType;
            this.defaultStats = defaultStats;
            
        }
        
        WeaponItem(String id) {

            WeaponItem weapon = WeaponItem.fromId(id);
            
            this.id = id;
            this.name = weapon.getName();
            this.description = weapon.getDescription();
            this.strengthReq = weapon.getStrengthReq();
            this.weaponType = weapon.getWeaponType();
            this.defaultStats = weapon.getDefaultStats();
            
        }
        
//GETTERS
        public WeaponItem getWeaponItem() {
        	WeaponItem weapon = WeaponItem.fromId(id);
        	return weapon;
        }
        public String getId() { return id; }
        public String getName() { return name; }
        public String getDescription() { return description; }
        public int getStrengthReq() { return strengthReq; }
        public WeaponType getWeaponType() { return weaponType; }
        public double[] getDefaultStats() { return defaultStats; }
        
    } //end WeaponItem enum
    
    
    
    //METHODS (Weapon class continued...)
    @Override
    public Item copy() {
    	
        return new Weapon(getWeaponItem(), getDamage(), getSpeed(), getDurability(), getQualityPercentage(), getValue());
        
    }

    
    
    //HELPER METHODS
    
//CONSTRUCTORS
    public Weapon(WeaponItem theWeapon, int damage, int speed, int durability, double qualityPercentage, int value) {
    	
        super( theWeapon.getName(), theWeapon.getDescription() ); // Call the Item constructor
    	this.theWeapon = theWeapon;
        this.damage = damage;
        this.speed = speed;
        this.durability = durability;
        this.qualityPercentage = qualityPercentage;
        this.value = value;
        
    }
    
    //null weapon constructor
    public Weapon() {
    	
    	super("None", "this is such a bruh momentum"); // Call the Item constructor
    	this.theWeapon = null;
        this.damage = 0;
        this.speed = 1;
        this.durability = 1;
        this.qualityPercentage = 1;
        this.value = 0;
        
    }
    
//GETTERS
    public WeaponItem getWeaponItem() { return theWeapon; }
    public int getStrengthReq() { return theWeapon.getStrengthReq(); }
    public WeaponType getWeaponType() { return theWeapon.getWeaponType(); }
    public int getDamage() { return damage; }
    public int getSpeed() { return speed; }
    public int getDurability() { return durability; }
    public double getQualityPercentage() { return qualityPercentage; }
    public int getValue() { return value; }
    @Override
    public String getItemType() { return "Weapon"; }
    
//SETTERS
    public void setWeapon(WeaponItem theWeapon) { this.theWeapon = theWeapon; }
    public void setDamage(int damage) { this.damage = damage; }
    public void setSpeed(int speed) { this.speed = speed; }
    public void setDurability(int durability) { this.durability = durability; }
    public void setQualityPercentage(double qualityPercentage) { this.qualityPercentage = qualityPercentage; }
    public void setValue(int value) { this.value = value; }

//TOSTRING for debugging
    @Override
    public String toString() {
        return "Weapon: " + theWeapon.getName() + ", Type: " + theWeapon.getWeaponType() + ", Damage: " + damage + ", Value: " + value;
    }
    
} //end of Weapon class